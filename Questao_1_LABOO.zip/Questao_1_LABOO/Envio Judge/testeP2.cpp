#include <iostream>
using namespace std;

// Faca os includes necessarios

void testeP2() {

    // Crie, nesta ordem as seguintes vacinas:
    // 2 vacinas da Coronavac no dia 20, e mais uma no dia 200
    // 1 vacinas da Jansen no dia 30, e mais uma no dia 300

    cout << "Criando vacinas" << endl;

    // Crie 2 passaportes: Judite e Ariel

    cout << "Criando passaportes" << endl;

    // Crie um cadastro de nome "Posto USP" e adicione a ele os 2 passaportes

    // Dica: Cadastro *c  .... COMPLETE
    cout << "Criando cadastro e adicionando passaportes" << endl;

    // Aplique as vacinas corretamente no modo abaixo:

    // Judite: Coronavac, fabricada no dia 20, 1a. dose no dia 10.
    // Ariel:  Jansen, fabricada no dia 30, no dia 40.

    cout << "Aplicando vacinas" << endl;

    // Imprima o cadastro

    // Tente aplicar a segunda dose de Coronavac (produzida no dia 20) em Judite no dia 350
    // Imprima em uma linha separada a mensagem referente ao tratamento da excecao

    // Aplique em Judite no dia 350 a dose de Coronavac produzida no dia 200

    // Tente agora aplicar em Ariel no dia 400 uma segunda dose de Jansen produzida no dia 300
    // Imprima em uma linha separada a mensagem referente ao tratamento da excecao

    // Imprima o cadastro

    // Destrua o cadastro
  }
