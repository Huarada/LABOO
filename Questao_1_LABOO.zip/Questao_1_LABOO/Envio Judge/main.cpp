#include <iostream>
#include "Vacina.h"
#include "Passaporte.h"
#include"Jansen.h"
#include "Coronavac.h"

using namespace std;

void testeP2();

int main() {
  testeP2();

  return 0;
}
