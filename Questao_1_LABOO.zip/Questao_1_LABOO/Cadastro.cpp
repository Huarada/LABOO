#include "Cadastro.h"
#include <stdexcept>
#include <iostream>

using namespace std;

// Implementar

Cadastro::Cadastro(string nomePosto)
{

}

Cadastro::~Cadastro()
{

}

string Cadastro::getNomePosto()
{

}

void Cadastro::adicionarPassaporte(Passaporte* passaporte)
{

}

vector<Passaporte*>* Cadastro::getPassaportes()
{

}

void Cadastro::imprimir()
{

}
