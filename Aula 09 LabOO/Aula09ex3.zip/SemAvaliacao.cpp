
#include "SemAvaliacao.h"
#include <stdexcept>
#include <string>

SemAvaliacao::SemAvaliacao(string mensagem): invalid_argument(mensagem){};

SemAvaliacao:: ~SemAvaliacao(){

}
